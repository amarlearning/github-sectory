from setuptools import setup

setup(
	name='github-sectory',
	version='1.1.0',
	scripts=['github-sectory']
)