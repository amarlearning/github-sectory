from setuptools import setup

setup(
	name='github-sectory',
	version='1.0.0',
	scripts=['main']
)